package hu.itatti.saunamaster.data

data class MasterList(
    var uid: String = "",
    var name: String = "",
    var date: String = "",
    var hour: String = "",
    var address: String = ""
)
